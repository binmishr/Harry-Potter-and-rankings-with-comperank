library(testthat)
library(comperank)

test_check("comperank")
