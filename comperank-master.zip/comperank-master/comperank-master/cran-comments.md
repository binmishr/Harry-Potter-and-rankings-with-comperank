## Submission details

This submission is reaction to upcoming changes in 'tibble' 3.0.0.

## Test environments

* Local Ubuntu 18.04 install, R 3.6.3
* Debian on R-hub, R development version (2020-03-01 r77879)
* macOS 10.11 on R-hub, R 3.6.2
* win-builder, release and development version (2020-01-28 r77738)

## R CMD check results

0 errors | 0 warnings | 0 notes

---

## Reverse dependencies

There are no reverse dependencies.
